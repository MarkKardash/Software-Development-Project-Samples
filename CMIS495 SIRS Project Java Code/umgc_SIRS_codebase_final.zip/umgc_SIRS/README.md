# umgc_SIRS
A simple program to manage and calculate required UMGC online portal grades to achieve an intended grade. Created as a collaborative capstone project for UMGC 495
