module com.umgc.sirs {
		requires java.desktop;
}